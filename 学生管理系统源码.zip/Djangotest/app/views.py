from django.shortcuts import render
from django.http import HttpResponse
from . import models
# Create your views here.

def home(request):
    return render(request, "home.html")

LoginId = 0
def login(request):
    #判断请求类型
    if request.method =="GET":
        return render(request, "login.html")
    else:
        #从前端表单中获取输入的数据，即账号和密码
        name = request.POST.get("username", None)
        pwd = request.POST.get("password", None)
        #获取数据库中的账号密码数据
        emp = models.UserInfo.objects.values("username", "password", "UserId").filter(username=name)
        #判断根据账号筛选前端输入的数据是否存在于数据库中
        if emp.count() == 0:
            return render(request, "login.html", {"msg": "登录失败,账号不存在"})
        else:
            if emp[0]['password'] == pwd:
                globals()["LoginId"] = emp[0]['UserId']

                return render(request, "welcome.html")
            else:
                return render(request, "login.html", {'msg': '登陆失败,密码错误'})

def welcome(request):
    return render(request, 'welcome.html')

'''
def add(request):

    list = ['id', 'stuname', 'stuphone', 'stuaddress', 'stucollege', 'stumajor']
    info = []
    for li in list:
        info.append(request.POST.get(li))
    print(info)
    if globals()["LoginId"] != 1:
        return HttpResponse('非ROOT权限，无权修改')

    emp = models.StuInfo.objects.filter(id=(info[0]))
    if emp.count() != 0:
        return render(request, 'add.html', {'msg': '该员工已经存在'})

    models.StuInfo.objects.create(id=(info[0]), stuname=info[1], stuphone=info[2], stuaddress=info[3],
                                  stucollege=info[4], stumajor=info[5])
    return render(request, 'add.html', {'msg': 'hello'})




def add(request):
    msg = ''
    if request.method == 'POST':
        id = request.POST.get('id')
        stuname = request.POST.get('stuname')
        stuphone = request.POST.get('stuphone')
        stuaddress = request.POST.get('stuaddress')
        stucollege = request.POST.get('stucollege')
        stumajor = request.POST.get('stumajor')
        stu = models.StuInfo()
        stu.id = id
        stu.stuname = stuname
        stu.stuphone = stuphone
        stu.stuaddress = stuaddress
        stu.stucollege = stucollege
        stu.stumajor = stumajor
        stu.save()
        msg = 'success'
    return render(request, 'add.html', {msg: 'msg'})


def add(request):
    if request.method=='GET':
        return render(request, 'add.html')
    elif request.method == 'POST':
        id = request.POST.get('id')
        stuname = request.POST.get('stuname')
        stuphone = request.POST.get('stuphone')
        stuaddress = request.POST.get('stuaddress')
        stucollege = request.POST.get('stucollege')
        stumajor = request.POST.get('stumajor')
        stu = models.StuInfo()
        stu.id = id
        stu.stuname = stuname
        stu.stuphone = stuphone
        stu.stuaddress = stuaddress
        stu.stucollege = stucollege
        stu.stumajor = stumajor
        stu.save()
        return render(request, 'add.html', {'result': '学生信息添加成功！'})
'''
def add(request):
    if request.method == 'GET':
        return render(request, 'add.html')
    elif request.method =='POST':
        list = ['id', 'stuname', 'stuphone', 'stuaddress', 'stucollege', 'stumajor']
        info = []
        for li in list:
            info.append(request.POST.get(li))
        if globals()['LoginId'] != 1:
            return HttpResponse("非root用户，没有权限添加用户！")
        s = models.StuInfo.objects.filter(id=info[0])
        print(s.count())
        #判断是否已存在重复的数据
        if len(s) != 0:
            return render(request, 'add.html', {'err': '学生信息已存在，请勿重复添加'})
        stu = models.StuInfo()
        stu.id = info[0]
        stu.stuname = info[1]
        stu.stuphone = info[2]
        stu.stuaddress = info[3]
        stu.stucollege = info[4]
        stu.stumajor = info[5]
        stu.save()  #保存数据
        return render(request, 'add.html', {'success': '学生信息添加成功!!'})
'''
def delete(request):
    if request.method == 'GET':
        return render(request, 'delete.html')
    else:
        id = request.POST.get('id', None)
        stu = models.StuInfo.objects.filter(id=id)
        print("==", stu)
        if stu.count == 0:
            return render(request, 'delete.html', {'err': '删除失败，没有此学生信息'})
        else:
            models.StuInfo.objects.filter(id=id).delete()
            return render(request, 'delete.html', {'success': '删除成功'})
'''
def delete(request):
    info = models.StuInfo.objects.all()
    if request.method == 'GET':
        return render(request, 'delete.html', {'info': info})
    if globals()['LoginId'] != 1:
        return render(request, 'delete.html', {'err': '非root用户登录，无权删除！'})
    id = request.POST.get('id', None)
    # print(id)
    if id.isspace() == True:
        return render(request, 'delete.html', {'err': '学号不能由空格组成,请重新输入！！！'})
    if len(id) == 0:
        return render(request, 'delete.html', {'err': '学号不能为空,请重新输入！！！'})
    emp = models.StuInfo.objects.filter(id=id)
    if emp.count() == 0:
        return render(request, 'delete.html', {'err': '该用户不存在,请重新输入！！！'})
    if globals()['LoginId'] != 1:
        return render(request, 'delete.html', {'err': '权限不够，请用 root 账号登录'})
    models.StuInfo.objects.filter(id=id).delete()
    return render(request, 'delete.html', {'info': info, 'success': '删除成功'})

def update(request):
    if request.method =='GET':
        return render(request, 'update.html')
    list = ['id', 'stuname', 'stuphone', 'stuaddress', 'stucollege', 'stumajor']
    info = []
    for li in list:
        info.append(request.POST.get(li))
    if globals()['LoginId'] != 1:
        return render(request, 'update.html', {'err': '权限不够，请切换为 root 用户重试'})
    id = request.POST.get('id', None)
    if id.isspace() == True:
        return render(request, 'update.html', {'err': '学号不能为空格组成,请重新输入！'})
    s = models.StuInfo.objects.filter(id=info[0])
    if s.count() == 0:
        return render(request, 'update.html', {'err': '没有此学生信息，无法修改'})
    stu = models.StuInfo()
    stu.id = info[0]
    stu.stuname = info[1]
    stu.stuphone = info[2]
    stu.stuaddress = info[3]
    stu.stucollege = info[4]
    stu.stumajor = info[5]
    stu.save()
    return render(request, 'update.html', {'success': '学生信息修改成功！'})

def select(request):
    if request.method =='GET':
        return render(request, 'select.html')
    if globals()['LoginId'] != 1:
        return render(request, 'select.html', {'error': '非 root 用户，无法查看！点击重新登录！'})
    #从表单中获取id值
    id = request.POST.get('id', None)
    #判断id不能为空的字符串类型
    if id.isspace() == True:
        return render(request, 'select.html', {'err': "不能为空值,请重新输入！"})
    #从数据库根据id值将对应信息赋值给stu
    stu = models.StuInfo.objects.filter(id=id)
    if stu.count() == 0:
        return render(request, 'select.html', {'err': '没有查询到此学生信息，请确定是否录入系统'})
    info = models.StuInfo.objects.values('id', 'stuname', 'stuphone', 'stuaddress', 'stucollege', 'stumajor').filter(id=id)[0]
    print("info=", info)
    return render(request, 'select.html', info)

def info(request):
    if request.method == 'POST':
        return render(request, 'info.html')
    info = models.StuInfo.objects.all()
    print(info)
    return render(request, 'info.html', {"info": info})



